$(document).ready(function(){
    $('#history').DataTable( {
        "pagingType": "full_numbers",
        "searching": false,
        "ordering": false,
        "lengthChange": false,
    } );
});